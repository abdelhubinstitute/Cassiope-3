async def noop_coroutine() -> None:
    pass
